<?php

return [
    'welcome_message' => 'Bienvenue :name, ici tu peux voir ton skin en 3D',
    'noauth' => "vous n'êtes pas authentifier , merci de vous connecter pour voir votre skin",
    'login' => 'Connectez-vous à votre compte',
    'register' => 'créer un nouveau compte',
    'change_skin' => 'Modifier mon skin',
    'pause_animation' => 'Pause Animation',
    'resume_animation' => 'Reprendre Animation',
    'skin_load_error' => 'Échec du chargement du skin. Veuillez réessayer plus tard.',
    
];
