@extends('admin.layouts.admin')

@section('title', 'Admin plugin home')

@section('content')
    <div class="card shadow mb-4">
        <div class="card-body">
            <p>This is the admin page of your plugin</p>
        </div>
    </div>
@endsection
