<?php

return [
    'welcome_message' => 'Bienvenue :name, ici tu peux voir ton skin en 3D',
    'change_skin' => 'Modifier mon skin',
    'pause_animation' => 'Pause Animation',
    'resume_animation' => 'Reprendre Animation',
    'skin_load_error' => 'Échec du chargement du skin. Veuillez réessayer plus tard.',
    
];
