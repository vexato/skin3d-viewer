<?php

return [
    'welcome_message' => 'Welcome :name, here you can view your 3D skin',
    'change_skin' => 'Change my skin',
    'pause_animation' => 'Pause Animation',
    'resume_animation' => 'Resume Animation',
    'skin_load_error' => 'Failed to load skin. Please try again later.',
    
];